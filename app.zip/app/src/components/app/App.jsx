import React, { Component } from 'react';

class App extends Component {
  render() {
    return (
      <div>
        {/* <div className="App-header">
            <img src={logo} className="App-logo" alt="logo" />
            <h2>
              <FormattedMessage
                id="welcome.message"
                description="Welcome message"
                defaultMessage="Welcome to FX Alert"
              />
              <br />
              <FormattedDate value={new Date()}/>
              <br />
              <FormattedTime value={new Date()}/>
              <br />
              <FormattedRelative value={Date.now()}/>
              <br />
              <FormattedNumber value={10000000000}/>
              <br />
              <FormattedPlural
                value={9}
                one='message'
                other='messages'
              />
            </h2>
          </div>
              <Header />
              {this.props.children}
            <Footer /> */}
        HEllo world!fdsfdsf
      </div>
    );
  }
}

export default App;
